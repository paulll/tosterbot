"use strict";

Array.prototype.random = function () {
	var string = '';

	for (let element of this) {
		string += element.random ? element.random() : element;
	}

	return string;
};

Set.prototype.random = function () {
	var i = 0,
		index = Math.floor(Math.random() * this.size);
	for (let value of this) {
		if (i++ == index) {
			return value.random ? value.random() : value;
		}
	}
}

function restore(k, v) {
	if (v.hasOwnProperty('v')) {
		return new Set(v.v);
	}
	return v;
}

/**
 * Пример
 */

var code = '{"v":[[{"v":["a",[{"v":["","b"]},"e"],"c"]}," ",{"v":["a","b","c"]}," c"]]}',
	ast = JSON.parse(code, restore);

console.log(ast.random());